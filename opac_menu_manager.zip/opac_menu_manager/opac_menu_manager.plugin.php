<?php
/**
 * @Plugin Name: OPAC Menu Manager
 * @Description: Mengelola menu navigasi di OPAC secara dinamis dari halaman admin.
 * @Version: 6.3.0
 * @Author: Jushadi Arman Saz
 */

// Keamanan dasar SLiMS
if (!defined('INDEX_AUTH')) {
    die("Direct access is not allowed!");
}

// Mendaftarkan menu ke sidebar admin
if (class_exists('SLiMS\Plugins')) {
    $plugin = \SLiMS\Plugins::getInstance();
    $plugin->registerMenu('master_file', 'OPAC Menu Manager', __DIR__ . '/index.php');
}

/**
 * Fungsi global untuk merender ITEM-ITEM (LI) menu navigasi OPAC.
 * Versi ini sudah mendukung status menu aktif.
 */
function render_opac_menu_items() {
    $dbs = \SLiMS\DB::getInstance();
    
    $sql = "SELECT * FROM mst_opac_menu WHERE is_active = 1 ORDER BY parent_id ASC, menu_order ASC";
    $query = $dbs->query($sql);
    
    if (!$query || $query->rowCount() == 0) return;

    $menus = [];
    while ($row = $query->fetch(\PDO::FETCH_ASSOC)) {
        $menus[$row['parent_id']][] = $row;
    }

    // Ambil parameter halaman saat ini untuk menentukan status aktif
    $current_p = $_GET['p'] ?? null;

    $build_menu_html = function($parent_id) use (&$menus, &$build_menu_html, $current_p) {
        if (!isset($menus[$parent_id])) {
            return '';
        }

        $html = ($parent_id != 0) ? '<ul class="dropdown-menu">' : '';
        
        foreach ($menus[$parent_id] as $menu_item) {
            $has_submenu = isset($menus[$menu_item['menu_id']]);
            
            // --- LOGIKA STATUS AKTIF DIMULAI DI SINI ---
            $is_active = false;
            // Cek apakah URL menu mengandung parameter 'p'
            parse_str(parse_url($menu_item['menu_url'], PHP_URL_QUERY) ?? '', $query_params);
            $menu_p = $query_params['p'] ?? null;

            if (is_null($current_p) && is_null($menu_p) && basename($menu_item['menu_url']) === 'index.php') {
                // Kasus untuk Homepage (tidak ada parameter 'p')
                $is_active = true;
            } elseif (!is_null($current_p) && $current_p === $menu_p) {
                // Kasus untuk halaman lain (parameter 'p' cocok)
                $is_active = true;
            }
            // --- AKHIR LOGIKA STATUS AKTIF ---

            $li_class = 'nav-item';
            if ($has_submenu) { $li_class .= ' dropdown'; }
            if ($is_active) { $li_class .= ' active'; } // Tambahkan kelas 'active' jika cocok
            
            $a_class = 'nav-link';
            $a_attrs = 'href="' . $menu_item['menu_url'] . '" target="' . $menu_item['menu_target'] . '"';
            if ($has_submenu) {
                $a_class .= ' dropdown-toggle';
                $a_attrs .= ' id="navbarDropdown' . $menu_item['menu_id'] . '" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"';
            }

            $html .= '<li class="' . $li_class . '">';
            $html .= '<a class="' . $a_class . '" ' . $a_attrs . '>';
            $html .= htmlspecialchars($menu_item['menu_title']);
            if ($has_submenu && $parent_id == 0) {
                $html .= ' <span class="caret"></span>';
            }
            $html .= '</a>';
            
            if ($has_submenu) {
                $html .= $build_menu_html($menu_item['menu_id']);
            }

            $html .= '</li>';
        }

        $html .= ($parent_id != 0) ? '</ul>' : '';
        return $html;
    };

    echo $build_menu_html(0);
}