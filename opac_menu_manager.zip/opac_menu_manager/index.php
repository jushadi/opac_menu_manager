<?php
/**
 * @File: OPAC Menu Manager - Admin Interface
 * @Version: 7.2 (Improved Hierarchical Display)
 */

// Keamanan dasar dan inisialisasi sesi
//if (!defined('INDEX_AUTH')) { die("Direct access is not allowed!"); }
require SB . 'admin/default/session.inc.php';
require SB . 'admin/default/session_check.inc.php';
if ($_SESSION['uid'] != 1) { die('<div class="errorBox">' . __('You are not authorized to view this section') . '</div>'); }

// Memuat pustaka SLiMS
require SIMBIO . 'simbio_GUI/table/simbio_table.inc.php';
require SIMBIO . 'simbio_GUI/form_maker/simbio_form_table_AJAX.inc.php';
require SIMBIO . 'simbio_DB/simbio_dbop.inc.php';

// Inisialisasi DB
$dbs = \SLiMS\DB::getInstance('mysqli');
$sql_op = new simbio_dbop($dbs);

//================ LOGIKA PROSES AKSI ================//

$action = $_GET['action'] ?? '';
$id = $_GET['menu_id'] ?? null;

// Aksi Hapus data
if ($action === 'delete' && $id) {
    $id = (int) $id;
    $sql_op->delete('mst_opac_menu', "parent_id = $id");
    $sql_op->delete('mst_opac_menu', "menu_id = $id");
    utility::jsToastr('Berhasil', 'Menu berhasil dihapus.', 'success');
    echo '<script>window.location.reload();</script>';
    exit;
}

// Aksi Simpan data (Tambah atau Edit)
if (isset($_POST['save'])) {
    $menu_id = (int)($_POST['menu_id'] ?? 0);
    $data['menu_title'] = trim($_POST['menu_title'] ?? '');

    if (empty($data['menu_title'])) {
        utility::jsToastr('Gagal', 'Judul Menu tidak boleh kosong.', 'error');
    } else {
        $data['parent_id'] = (int)($_POST['parent_id'] ?? 0);
        $data['menu_url'] = trim($_POST['menu_url'] ?? '#');
        $data['menu_target'] = in_array($_POST['menu_target'], ['_self', '_blank']) ? $_POST['menu_target'] : '_self';
        $data['is_active'] = isset($_POST['is_active']) ? 1 : 0;
        $data['menu_order'] = (int)($_POST['menu_order'] ?? 0);
        
        if ($menu_id > 0) {
            $data['last_update'] = date('Y-m-d H:i:s');
            $sql_op->update('mst_opac_menu', $data, "menu_id=$menu_id");
        } else {
            if ($data['menu_order'] == 0) {
                $max_order_q = $dbs->query("SELECT MAX(menu_order) FROM mst_opac_menu WHERE parent_id = {$data['parent_id']}");
                $max_order = $max_order_q ? $max_order_q->fetch_assoc()['MAX(menu_order)'] : 0;
                $data['menu_order'] = ($max_order ?? 0) + 1;
            }
            $data['input_date'] = date('Y-m-d H:i:s');
            $sql_op->insert('mst_opac_menu', $data);
        }
        utility::jsToastr('Berhasil', 'Data menu berhasil disimpan.', 'success');
    }
    exit;
}

//================ PENGAMBILAN DATA UNTUK TAMPILAN ================//

$edit_data = [
    'menu_id' => null, 'parent_id' => 0, 'menu_title' => '', 'menu_url' => 'index.php?p=',
    'menu_target' => '_self', 'is_active' => 1, 'menu_order' => 0
];

if ($action === 'edit' && $id) {
    $stmt = $dbs->prepare("SELECT * FROM mst_opac_menu WHERE menu_id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result) {
        $fetched_data = $result->fetch_assoc();
        if ($fetched_data) {
            $edit_data = array_merge($edit_data, $fetched_data);
        }
    }
}

// Ambil semua menu, diurutkan berdasarkan induk lalu nomor urut
$menus_query = $dbs->query("SELECT * FROM mst_opac_menu ORDER BY parent_id ASC, menu_order ASC");
$menus_list = $menus_query ? $menus_query->fetch_all(MYSQLI_ASSOC) : [];

// PERUBAHAN: Proses data menjadi struktur Parent-Child
$parent_menus = [];
$child_menus = [];
foreach ($menus_list as $menu) {
    if ($menu['parent_id'] == 0) {
        $parent_menus[] = $menu;
    } else {
        $child_menus[$menu['parent_id']][] = $menu;
    }
}
?>

<div class="s-main-content">
    <div class="s-page-header">
        <h3><i class="fa fa-list-alt"></i> OPAC Menu Manager</h3>
    </div>
    <div class="row">
        <div class="col-md-4" id="form">
            <fieldset class="block">
                <legend><?= ($action === 'edit' && $id) ? 'Edit Menu' : 'Tambah Menu Baru' ?></legend>
                <div class="s-portlet-content">
                    <?php
                    $form = new simbio_form_table_AJAX('mainForm', $_SERVER['PHP_SELF'] . '?' . $_SERVER['QUERY_STRING'], 'post');
                    $form->submit_button_attr = 'style="display: none;"';

                    $form->addHidden('menu_id', $edit_data['menu_id']);
                    $form->addTextField('text', 'menu_title', 'Judul Menu', $edit_data['menu_title'], 'style="width: 100%;" class="form-control" required');
                    $form->addTextField('text', 'menu_url', 'URL', $edit_data['menu_url'], 'style="width: 100%;" class="form-control" required');
                    
                    $number_input_html = '<input type="number" name="menu_order" id="menu_order" value="' . htmlspecialchars($edit_data['menu_order']) . '" class="form-control" style="width: 80px;" placeholder="Auto">';
                    $form->addAnything('Nomor Urut', $number_input_html);

                    $parent_options_html = '<select name="parent_id" class="form-control">';
                    $parent_options_html .= '<option value="0">Jadikan Menu Utama</option>';
                    // Opsi parent hanya dari menu utama
                    foreach ($parent_menus as $parent_menu) {
                        if ($parent_menu['menu_id'] != $edit_data['menu_id']) {
                            $selected = ($edit_data['parent_id'] == $parent_menu['menu_id']) ? 'selected' : '';
                            $parent_options_html .= '<option value="' . $parent_menu['menu_id'] . '" ' . $selected . '>' . htmlspecialchars($parent_menu['menu_title']) . '</option>';
                        }
                    }
                    $parent_options_html .= '</select>';
                    $form->addAnything('Sub-menu dari', $parent_options_html);
                    
                    $target_html = '<select name="menu_target" class="form-control"><option value="_self" ' . ($edit_data['menu_target'] == '_self' ? 'selected' : '') . '>Tab Saat Ini</option><option value="_blank" ' . ($edit_data['menu_target'] == '_blank' ? 'selected' : '') . '>Tab Baru</option></select>';
                    $form->addAnything('Target', $target_html);

                    $is_checked_attr = ($edit_data['is_active'] == 1) ? 'checked' : '';
                    $checkbox_html = '<input type="checkbox" name="is_active" value="1" ' . $is_checked_attr . '>';
                    $form->addAnything('Aktifkan Menu', $checkbox_html);

                    $buttons_html = '</td></tr><tr><td colspan="3" style="text-align: left; padding-top: 10px;">';
                    if ($action === 'edit' && $id) {
                        $cancel_url_params = $_GET;
                        unset($cancel_url_params['action'], $cancel_url_params['menu_id']);
                        $add_new_url = $_SERVER['PHP_SELF'] . '?' . http_build_query($cancel_url_params);
                        $buttons_html .= '<button type="submit" name="save" class="btn btn-xs btn-success">Perbarui</button> ';
                        $buttons_html .= '<a href="' . $add_new_url . '" class="btn btn-xs btn-primary"><i class="fa fa-plus"></i> Tambah Baru</a>';
                    } else {
                        $buttons_html .= '<button type="submit" name="save" class="btn btn-xs btn-success">Simpan</button>';
                    }
                    $buttons_html .= '</td>';
                    $form->addAnything('Tombol', $buttons_html);

                    echo $form->printOut();
                    ?>
                </div>
            </fieldset>
        </div>

        <div class="col-md-8">
            <fieldset class="block">
                <legend>Daftar Menu Tersimpan</legend>
                <div class="s-portlet-content" style="padding: 15px;">
                    <table class="s-table table-bordered">
                        <thead>
                            <tr class="dataListHeader">
                                <th style="width: 50px;">No. Urut</th>
                                <th>Judul Menu</th>
                                <th>URL</th>
                                <th>Status</th>
                                <th style="width: 120px;">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($parent_menus): ?>
                                <?php foreach ($parent_menus as $parent): ?>
                                    <tr>
                                        <td class="text-center"><?= $parent['menu_order']; ?></td>
                                        <td><strong><?= htmlspecialchars($parent['menu_title']); ?></strong></td>
                                        <td><code><?= htmlspecialchars($parent['menu_url']); ?></code></td>
                                        <td><?= $parent['is_active'] ? '<span class="label label-success">Aktif</span>' : '<span class="label label-danger">Non-Aktif</span>'; ?></td>
                                        <td>
                                            <div class="btn-group">
                                                <a href="<?= $_SERVER['PHP_SELF'] . '?' . http_build_query(array_merge($_GET, ['action' => 'edit', 'menu_id' => $parent['menu_id']])) . '#form'; ?>" class="btn btn-xs btn-info">Edit</a>
                                                <a href="<?= $_SERVER['PHP_SELF'] . '?' . http_build_query(array_merge($_GET, ['action' => 'delete', 'menu_id' => $parent['menu_id']])); ?>" class="btn btn-xs btn-danger delete-btn">Hapus</a>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php // Tampilkan semua anak dari parent ini
                                    if (isset($child_menus[$parent['menu_id']])): ?>
                                        <?php foreach ($child_menus[$parent['menu_id']] as $child): ?>
                                            <tr>
                                                <td class="text-center"><?= $child['menu_order']; ?></td>
                                                <td><span class="text-muted" style="padding-left: 20px;">↳</span>&nbsp;<?= htmlspecialchars($child['menu_title']); ?></td>
                                                <td><code><?= htmlspecialchars($child['menu_url']); ?></code></td>
                                                <td><?= $child['is_active'] ? '<span class="label label-success">Aktif</span>' : '<span class="label label-danger">Non-Aktif</span>'; ?></td>
                                                <td>
                                                    <div class="btn-group">
                                                        <a href="<?= $_SERVER['PHP_SELF'] . '?' . http_build_query(array_merge($_GET, ['action' => 'edit', 'menu_id' => $child['menu_id']])) . '#form'; ?>" class="btn btn-xs btn-info">Edit</a>
                                                        <a href="<?= $_SERVER['PHP_SELF'] . '?' . http_build_query(array_merge($_GET, ['action' => 'delete', 'menu_id' => $child['menu_id']])); ?>" class="btn btn-xs btn-danger delete-btn">Hapus</a>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="5" class="text-center">Belum ada data menu.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </fieldset>
        </div>
    </div>
</div>

<script>
$(document).on('click', '.delete-btn', function(e) {
    e.preventDefault();
    const deleteUrl = $(this).attr('href');

    Swal.fire({
        title: 'Anda Yakin?',
        text: "Data yang dihapus tidak dapat dikembalikan!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Ya, hapus!',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: deleteUrl,
                type: 'GET',
                success: function(response) {
                    window.location.reload();
                }
            });
        }
    })
});
</script>