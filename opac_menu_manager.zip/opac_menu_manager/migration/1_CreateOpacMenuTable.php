<?php
/**
 * @Plugin Name: OPAC Menu Manager
 * @Description: Migrasi untuk membuat tabel mst_opac_menu dan mengisinya dengan data awal.
 * @Version: 1.2 (Stable Migration)
 * @Author: SLiMS Core Programmer
 */

use SLiMS\DB;
use SLiMS\Migration\Migration;

class CreateOpacMenuTable extends Migration
{
    /**
     * Menjalankan migrasi untuk membuat tabel dan mengisi data awal.
     *
     * @return void
     */
    public function up()
    {
        $dbs = DB::getInstance();

        // 1. Buat tabel jika belum ada
        $sql_create = <<<SQL
        CREATE TABLE IF NOT EXISTS `mst_opac_menu` (
          `menu_id` int(11) NOT NULL AUTO_INCREMENT,
          `parent_id` int(11) NOT NULL DEFAULT 0,
          `menu_title` varchar(100) NOT NULL,
          `menu_url` text NOT NULL,
          `menu_target` enum('_self','_blank') NOT NULL DEFAULT '_self',
          `menu_order` int(11) NOT NULL DEFAULT 0,
          `is_active` tinyint(1) NOT NULL DEFAULT 1,
          `input_date` datetime DEFAULT NULL,
          `last_update` datetime DEFAULT NULL,
          PRIMARY KEY (`menu_id`),
          KEY `parent_id` (`parent_id`),
          KEY `is_active` (`is_active`)
        ) ENGINE=Aria DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        SQL;
        $dbs->query($sql_create);

        // 2. Cek apakah tabel kosong
        $check_q = $dbs->query("SELECT COUNT(*) as total FROM mst_opac_menu");
        $count = $check_q ? (int)$check_q->fetch(\PDO::FETCH_ASSOC)['total'] : 0;

        // 3. Jika kosong, isi dengan data menu default SLiMS
        if ($count === 0) {
            // Data menu default (tanpa fungsi terjemahan untuk keamanan migrasi)
            $default_menus = [
                ['title' => 'Home', 'url' => 'index.php', 'order' => 1],
                ['title' => 'Information', 'url' => 'index.php?p=libinfo', 'order' => 2],
                ['title' => 'News', 'url' => 'index.php?p=news', 'order' => 3],
                ['title' => 'Help', 'url' => 'index.php?p=help', 'order' => 4],
                ['title' => 'Librarian', 'url' => 'index.php?p=librarian', 'order' => 5]
            ];
            
            // Gunakan prepared statement untuk keamanan dan kompatibilitas PDO
            $stmt = $dbs->prepare("INSERT INTO `mst_opac_menu` (`menu_title`, `menu_url`, `menu_order`, `input_date`) VALUES (?, ?, ?, NOW())");
            
            foreach ($default_menus as $menu) {
                $stmt->execute([$menu['title'], $menu['url'], $menu['order']]);
            }
        }
    }

    /**
     * Membatalkan migrasi (menghapus tabel).
     *
     * @return void
     */
    public function down()
    {
        DB::getInstance()->query("DROP TABLE IF EXISTS `mst_opac_menu`");
    }
}
